// 存储 CSV 数据的全局变量
var chartData;

// 将 PapaParse 的引入放入一个 Promise 中
function loadCSV() {
    return new Promise((resolve) => {
        // 在这里导入 PapaParse 库，用于解析 CSV 数据
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.0/papaparse.min.js';
        script.onload = resolve;
        document.head.appendChild(script);
    });
}

// 读取 CSV 文件并处理数据
function parseCSV() {
    return new Promise((resolve) => {
        Papa.parse('data_test.csv', {
            download: true,
            header: true,
            complete: function (results) {
                chartData = results.data;
                resolve();
            }
        });
    });
}

// 导入 PapaParse 和 Chart.js，并在加载完成后执行回调
function importScripts(callback) {
    var papaScript = document.createElement('script');
    papaScript.type = 'text/javascript';
    papaScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.0/papaparse.min.js';
    papaScript.onload = function () {
        var chartScript = document.createElement('script');
        chartScript.type = 'text/javascript';
        chartScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js';
        chartScript.onload = callback;
        document.head.appendChild(chartScript);
    };
    document.head.appendChild(papaScript);
}


// -------------------------业务逻辑部分-------------------------------
// 存储当前的 Chart 对象
var chartCanvas;

// 标志位，用于确保销毁和创建 Canvas 操作不交叉进行
var chartCanvasInUse = false;


// 处理搜索城市的函数
function searchCity() {
    var searchInput = document.getElementById('citySearch');
    var cityName = searchInput.value.trim();

    if (cityName !== '') {
        var cityData = chartData.find((row) => row.NAME_CH === cityName);

        console.log('search City Data:', cityData); // 添加日志

        if (cityData) {
            showChartByProvince(cityName);
        } else {
            alert('未找到该城市的数据');
        }
    } else {
        alert('请输入城市名称');
    }
}


// 定义显示图表的函数
async function showChartByProvince(city) {
    if (!chartData || chartCanvasInUse) {
        console.log('ChartData is undefined or Canvas is in use.'); // 添加日志
        return;
    }

    // 设置标志位，表示当前正在使用 Canvas
    chartCanvasInUse = true;

    // 销毁当前的 Chart 对象
    if (chartCanvas) {
        chartCanvas.destroy();
        chartCanvas = null; // 设置为 null，确保之后重新创建新的实例
    }

    var cityData = chartData.find((row) => row.NAME_CH === city);

    console.log('show City Data:', cityData);  // 添加这行日志

    if (cityData) {
        document.getElementById("chartContainer").style.display = "block";

        // 延迟一段时间后再创建新的 Canvas 元素
        await new Promise(resolve => setTimeout(resolve, 100));

        chartCanvas = new Chart(document.getElementById('myChart'), {
            type: 'bar',
            data: {
                labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                datasets: [{
                    label: city, // 设置标签为点击的地点名称
                    data: Object.values(cityData).slice(2),  // 从第三个元素开始（索引2），即从'1月'开始
                    backgroundColor: 'rgba(75, 192, 192, 0.6)', // 调整背景颜色和透明度
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2
                }]
            },
            options: {
                scales: {
                    x: {
                        grid: {
                            display: false // 隐藏x轴网格线
                        },
                        ticks: {
                            font: {
                                size: 12 // 调整x轴刻度字体大小
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)' // 设置y轴网格线颜色
                        },
                        ticks: {
                            font: {
                                size: 12 // 调整y轴刻度字体大小
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top', // 设置图例位置为顶部
                        labels: {
                            font: {
                                size: 14 // 调整图例字体大小
                            }
                        }
                    }
                }
            }
        });
    } else {
        hideChart();
    }

    // 重置标志位，表示当前不再使用 Canvas
    chartCanvasInUse = false;
}

// 隐藏图表的函数
function hideChart() {
    document.getElementById("chartContainer").style.display = "none";

    // 销毁当前的 Chart 对象
    if (chartCanvas) {
        chartCanvas.destroy();
        chartCanvas = null; // 设置为 null，确保之后重新创建新的实例
    }
}

// 处理地图点击事件
function handleMapClick(event) {
    var coordinate = event.coordinate;
    var feature = map.forEachFeatureAtPixel(event.pixel, function (feature) {
        return feature;
    });

    // 判断点击位置是否在省份或县级市区域
    if (feature) {
        var provinceName = feature.get("NAME_CH");

        if (provinceName) {
            // 输出省份名称
            console.log("点击的地点名称:", provinceName);
        }

        
        // 调用 showChartByProvince 函数
        showChartByProvince(provinceName);
    } else {
        // 如果点击位置不在省份或县级市区域，隐藏图表
        hideChart();
    }
}

// 加载 PapaParse 和 Chart.js，然后解析 CSV 文件，最后执行其他操作
importScripts(function () {
    loadCSV()
        .then(parseCSV)
        .then(() => {
            // 在这里可以访问全局变量 chartData，以确保数据已正确加载
            console.log('CSV 数据:', chartData);

            // 其他图表相关的代码

            // 例如，这是一个显示图表的示例函数
            // showChartByProvince('齐齐哈尔副都统辖区');

            // 其他图表相关的代码结束

        })
        .catch((error) => console.error('加载或解析 CSV 文件时出错:', error));

});


// -------------------------地图部分--------------------------------
var apiKey = "AgXWxa8RRy37MM7dP1x8TAbEwF_4ycGxcUXLeseYJ2A7J1b25tD6y6PEbe4udlYD";

var chinaCenter = ol.proj.fromLonLat([104.195397, 35.86166]); // 中国中心的坐标
var initialZoom = 4.4;

var map = new ol.Map({
    target: "map",
    layers: [
        new ol.layer.Tile({
            source: new ol.source.BingMaps({
                key: apiKey,
                imagerySet: "Aerial",
            }),
        }),
    ],
    view: new ol.View({
        center: chinaCenter,
        zoom: initialZoom,
    }),
});

var vectorSource = new ol.source.Vector();
var vectorLayer = new ol.layer.Vector({
    source: vectorSource,
    style: function (feature, resolution) {
        var text = feature.get("NAME_CH");
        var textStyle = new ol.style.Text({
            text: text,
            fill: new ol.style.Fill({
                color: "white",
            }),
            stroke: new ol.style.Stroke({
                color: "black",
                width: 2,
            }),
        });
        return new ol.style.Style({
            text: textStyle,
            stroke: new ol.style.Stroke({
                color: "rgb(177, 197, 180)",
                width: 2,
            }),
            fill: new ol.style.Fill({
                color: 'rgba(0, 0, 255, 0.1)' // 添加省份轮廓的填充颜色
            })
        });
    },
});

map.addLayer(vectorLayer);

var jsonFiles = [
    "https://raw.githubusercontent.com/ChenSK23/GIS/main/Export_Output.json",
    "https://raw.githubusercontent.com/ChenSK23/GIS/main/Export_Output_5.json"
];

function updateData() {
    var currentZoom = map.getView().getZoom();
    var zoomLevel = Math.floor(currentZoom);
    var vectorSource = vectorLayer.getSource();
    vectorSource.clear();

    if (zoomLevel >= 4 && zoomLevel < jsonFiles.length + 4) {
        var jsonFileIndex = zoomLevel - 4;
        fetch(jsonFiles[jsonFileIndex])
            .then((response) => response.json())
            .then((data) => {
                vectorSource.addFeatures(
                    new ol.format.GeoJSON().readFeatures(data, {
                        featureProjection: "EPSG:3857",
                    })
                );
            });
    } else if (zoomLevel >= jsonFiles.length + 2) {
        var jsonFileIndex = jsonFiles.length - 1;
        fetch(jsonFiles[jsonFileIndex])
            .then((response) => response.json())
            .then((data) => {
                vectorSource.addFeatures(
                    new ol.format.GeoJSON().readFeatures(data, {
                        featureProjection: "EPSG:3857",
                    })
                );
            });
    }

    // 移除之前可能已经添加的点击事件监听器
    map.un("click", handleMapClick);
    
    // 添加点击事件监听器
    map.on("click", handleMapClick);

    // 其他更新数据的逻辑...
}

map.on("moveend", updateData);
updateData();


