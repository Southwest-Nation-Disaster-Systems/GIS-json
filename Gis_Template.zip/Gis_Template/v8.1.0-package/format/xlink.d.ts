/**
 * @param {Element} node Node.
 * @return {string|undefined} href.
 */
export function readHref(node: Element): string | undefined;
//# sourceMappingURL=xlink.d.ts.map