declare namespace _default {
    let LAYERGROUP: string;
    let SIZE: string;
    let TARGET: string;
    let VIEW: string;
}
export default _default;
//# sourceMappingURL=MapProperty.d.ts.map